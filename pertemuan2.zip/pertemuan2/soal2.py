"""
2. Diberikan sebuah tuple data mahasiswa:
mahasiswa = ("A001", "Budi", "Informatika")

"""
print("---------------------------------------------------------------------------------------------------")
#1. Tampilkan nama mahasiswa dari tuple tersebut.
print("SOAL 2.1")
mahasiswa = ("A001", "Budi", "Informatika")
print(mahasiswa[1])

print("---------------------------------------------------------------------------------------------------")
#2. Tampilkan seluruh isi tuple menggunakan perulangan for.
print("SOAL 2.2")
mahasiswa = ("A001", "Budi", "Informatika")
for x in mahasiswa:
    print(x)

print("---------------------------------------------------------------------------------------------------")
#2. Jelaskan satu alasan mengapa tuple tidak bisa diubah..
print("SOAL 2.3")
print("agar sekumpulan nilai tetap tidak berubah")

print("---------------------------------------------------------------------------------------------------")